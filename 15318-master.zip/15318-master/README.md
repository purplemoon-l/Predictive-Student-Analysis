# 15318
Prophet AI, a predictive student analysis system to help students choose their right career path. 

Tech-stack:

Front-end : https://github.com/Aivi001/15318/blob/master/student-app-ui-development.zip
Back-end: https://github.com/Aivi001/15318/blob/master/student-app-backend-development.zip

Additionally,
-> TensorFlow
-> MySQL
-> Angular 5
-> Flask
-> Python

